package com.amrita.jpl.cys21045.p2;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class QuizGameServer extends QuizGame {
    private List<String> questions;
    private List<QuizGameListener> listeners;

    public QuizGameServer() {
        questions = new ArrayList<>();
        questions.add("What is the father of the nation?");
        questions.add("What is the capital of India?");
        questions.add("Who is the fastest to reach no1 odi rankings?");

        listeners = new ArrayList<>();
    }

    // Server-side code
    @Override
    void startGame() {
        askQuestion();
    }

    @Override
    void askQuestion() {
        Random random = new Random();
        int index = random.nextInt(questions.size());
        String question = questions.get(index);

        // Notify listeners about the question
        for (QuizGameListener listener : listeners) {
            listener.onQuestionAsked(question);
        }
    }

    @Override
    void evaluateAnswer(String answer) {
        boolean isCorrect = false;
        // Perform answer evaluation logic
        if (answer.equalsIgnoreCase("Mahatma Gandhi")) {
            isCorrect = true;
        } else if (answer.equalsIgnoreCase("Delhi")) {
            isCorrect = true;
        } else if (answer.equalsIgnoreCase("MSD")) {
            isCorrect = true;
        }

        // Notify listeners about the answer evaluation
        for (QuizGameListener listener : listeners) {
            listener.onAnswerEvaluated(isCorrect);
        }
    }

    public void addListener(QuizGameListener listener) {
        listeners.add(listener);
    }
}
public class Server {
    public static void main(String[] args) {
        QuizGameServer server = new QuizGameServer();
        server.startGame();
    }
}