package p2.p2;public class quizgameclient {
}
